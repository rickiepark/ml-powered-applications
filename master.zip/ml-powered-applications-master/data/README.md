This folder is where you should download stackoverflow archives and keep your
transformed data if you choose to do these steps on your own.

I have provided a version of the preprocessed data for convenience.
