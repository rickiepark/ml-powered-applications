This folder contains trained models and vectorizers. When you run the notebooks
in this repository it will overwrite these files, make sure to make a copy or
work from a separate branch if you want to keep the originals.
